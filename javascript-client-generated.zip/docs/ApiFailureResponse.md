# Mandelbrot.ApiFailureResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **String** |  | [optional] 


<a name="MessageEnum"></a>
## Enum: MessageEnum


* `CLIENT ERROR` (value: `"CLIENT ERROR"`)

* `SERVER ERROR` (value: `"SERVER ERROR"`)




