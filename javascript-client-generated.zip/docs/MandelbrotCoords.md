# Mandelbrot.MandelbrotCoords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**y** | **Number** |  | 
**xmin** | **Number** |  | 
**dx** | **Number** |  | 
**columns** | **Number** |  | 
**maxIterations** | **Number** |  | 


