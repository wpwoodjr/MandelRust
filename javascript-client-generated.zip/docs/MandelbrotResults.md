# Mandelbrot.MandelbrotResults

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


