'use strict';


/**
 * Iterate over pixels to determine if each is in the Mandelbrot set
 * 
 *
 * mandelbrotCoords MandelbrotCoords Mandelbrot coordinates to compute
 * returns MandelbrotResults
 **/
exports.computeMandelbrot = function(mandelbrotCoords) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

